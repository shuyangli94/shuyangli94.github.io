## Overview

This contains a corpus of 2,000 movie reviews from IMDB, processed to only retain subjective sentences and marked for sentence polarity and summarization.
The `pos` folder contains 1,000 positive movie reviews. The `neg` folder contains 1,000 negative movie reviews.
Each file consists of 1 movie review, with newline-separated sentences. Processing:

1. Sentences lacking opinions have been removed.
2. Lines of opposite polarity from the review (praise in a negative review, criticism in a positive review) are marked with one star (*)
3. The line most indicative of the reviewer's overall opinion is marked with three stars (***)

### Citation Info
This dataset is free to use for any research or academic purpose. Please mention the labeler (Shuyang Li), as well as cite the source of the raw data:
```
"A Sentimental Education: Sentiment Analysis Using Subjectivity Summarization Based on Minimum Cuts",  Proceedings of the ACL, 2004.

@InProceedings{Pang+Lee:04a,
  author =       {Bo Pang and Lillian Lee},
  title =        {A Sentimental Education: Sentiment Analysis Using Subjectivity Summarization Based on Minimum Cuts},
  booktitle =    "Proceedings of the ACL",
  year =         2004
}
```

### Author Information
Data manually labeled by [Shuyang Li](mailto:shuyangl@alumni.princeton.edu) in 2015-2016 while a student at Princeton University.
Raw movie reviews from the [Cornell IMDB Polarity Dataset v2.0](http://www.cs.cornell.edu/people/pabo/movie-review-data/) (Pang/Lee ACL 2004).